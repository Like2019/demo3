/** 随机产生一个指定范围内的整数 */
function randomInt(min, max) {
	return parseInt(Math.random() * (max + 1 - min) + min);
}

function trim(str) {
	var arr = [];
	for (var i = 0; i < str.length; i++) {
		if (str.charCodeAt(i) != 32) {
			arr.push(str[i]);
		}
	}
	return arr.join("");
}

function log(obj) {
	console.log(obj);
}

function getByClassName(classname) {
	if (document.getElementsByClassName) {
		return document.getElementsByClassName(classname);
	} else {
		var all = document.getElementsByTagName("*");
		var arr = [];
		for (var i = 0; i < all.length; i++) {
			if (all[i].className == classname) {
				arr.push(all[i]);
			}
		}
		return arr;
	}
}

function getChildElements(obj) {
	var nodeList = obj.childNodes;
	var arr = new Array();
	for (var i = 0; i < nodeList.length; i++) {
		if (nodeList[i].nodeType == 1) {
			arr.push(nodeList[i]);
		}
	}
	return arr;
}

function addEvent(target, eventName, fun, bubble) {
	if (target.attachEvent) {
		target.attachEvent("on" + eventName, fun);
	} else {
		target.addEventListener(eventName, fun, bubble);
	}
}

function getCookie(key) {
	var cookiestr = document.cookie;
	var list = cookiestr.split(";");
	for (var i in list) {
		var arr = list[i].split("=");
		if (trim(arr[0]) == key) {
			return arr[1];
		}
	}
	return null;
}