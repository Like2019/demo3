(function(){
    /*_.templateSettings = {
        evaluate: /\{\{([\s\S]+?)\}\}/g,
        interpolate: /\{\{=([\s\S]+?)\}\}/g,
        escape: /\{\{-([\s\S]+?)\}\}/g
    };*/
    $.fn.dlg = function(options){
        var setting = $.extend({
            'clazz'  : '',
            'content': '',
            'title'  : '提示',
            'mask'   : 1,
            'clazz'  : '',
            'modal'  : 0,
            'clear'  : 1, //清除其它dlg
            'scroll' : 1, //阻止滚动 1可滚动，0不可滚
            'btns'   : '<button class="dlg-btn" dlg-act="done">确 定</button> <button class="dlg-btn" dlg-act="cancel">取 消</button>',
            'btnsText': {ok:'确 定', no:'取 消'},
            'tpl'    : $('#comicDlgTpl').html(),
            'z-index': 1000,
            'closeCall': null,
            'callback': null
        }, options);
        var $content = $('.content, body > .bar');
        var _scrollY = 0;
        var $mask;


        function preventScroll(e){
            e.preventDefault();
        }

        function position(modal, mask){
            var _scrollY = window.scrollY;
            var height = modal.height();
            var top = _scrollY;
            var _hegiht = document.body.scrollHeight
            modal.css({
                'top': 0,
                'position': 'absolute',
                'width': '100%',
                'height': _hegiht,
                'left': 0
            })
            modal.find('.dlg').css({
                'top': top,
            })
            $mask.css({
                'position': 'absolute',
                'width': '100%',
                'height': _hegiht
            });

        }
        function dlgCls(e, modal, call){
            e && e.preventDefault();
            var close = true;
            $mask.unbind();
            modal.removeClass('active');

            $(document).off('touchmove', preventScroll);
            if(close || close === undefined) {
                setTimeout(function(){
                    if( setting.modal ) {
                        alert('her');
                        $content.show();
                        window.scrollTo(0, _scrollY);
                    }
                    if(setting[call]) close = setting[call].call(modal);

                    if(!close) {
                        modal.remove();
                        $mask.remove();
                        modal = null;
                        $mask = null;
                    }
                }, 200);
            }
        }
        return this.each(function(){
            _scrollY = window.scrollY;
            //$content.hide();
            var modal = $(this).html($(_.template(setting.tpl)(setting)));
            if( setting.clear ) {
                $('[dlg-type="dlg"]').remove();
            }
            modal.attr('dlg-type', 'dlg')
                .appendTo('body')
                .find('[dlg-act="cancel"]')
                .on('tap', function(e){

                    dlgCls(e, modal, 'closeCall');
                });
            $mask = modal.find('.mask');
            position(modal);
            modal.find('textarea, input').trigger('focus');
            modal.find('textarea, input').on('focus blur', function(){
                position(modal);
            });

            if( setting.modal ) {
                $content.hide();
                setTimeout(function(){
                    modal.addClass('modal');
                },100);
            }

            if( !setting.scroll ) {
                $(document).on('touchmove', preventScroll);
            }

            modal.on('close', function(e){
                dlgCls(e, modal, 'closeCall');
            });
            modal
                .find('[dlg-act="done"]')
                .on('tap', function(e){
                    dlgCls(e, modal, 'callback');
                });
            setTimeout(function(){
                modal.addClass('active');
                //__disableScroll = true;
            }, 100);
            return this;
        });
    };
})($);



