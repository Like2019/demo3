define(['jquery'], function(){
    var meta =  MANHUA.meta;
    var backurl = encodeURIComponent(location.href)||0;
    //https://passport.weibo.cn/signin/login?entry=mweibo&res=wel&wm=3349&r=http%3A%2F%2Fm.weibo.cn%2F
    return {
        isLogin: meta.sina_user_id,
        loginUrl:  MANHUA.loginUrl + backurl,
        require: function(){
            if(!this.isLogin) {
                this.login();
                return true;
            }
            return false;
        },
        login: function(){
            location.href = this.loginUrl
        }
    }
});