define(['utils', 'dlg', 'backbone', 'login'], function (utils, dlg, Backbone, Login) {
    //console.log( 'IZoom', IZoom );
    //IZoom = IScroll;
    var comic      = window.comic || {};
    var COMIC_JSON = json_content;
    var TC_ROW_NUM = MANHUA.tcRowNum || 20;
    var URL_ROOT   = MANHUA.urlRoot;
    var AJAX_API   = MANHUA.ajaxApi();
    var MANHUA_META = MANHUA.meta;
    var CURRENT_CHAPTER = MANHUA_META['chapter_id'];
    var isLogin    = Login.isLogin; //是否登陆
    var TC_SHOW_NAME = 'vmh_tc_show';
    var TC_SHOW_EXPIRES = {expires: 365};
    var TC_SHOW = MANHUA.tcShow && (utils.cookie(TC_SHOW_NAME)>0 || utils.localStorage(TC_SHOW_NAME)>0) ? 1 : 0;

    var ComicModel = Backbone.Model.extend({
        _save: function(attributes, options){
            $.ajax($.extend({
                url: this.url,
                timeout: 60*1000,
                dataType: 'json',
                cache: false,
                data: $.extend(this.toJSON(), attributes||{}),
            }, options||{}) );
        }
    });
    //  Comic Model
    var ComicModel = ComicModel.extend({
        defaults: {
            "imgUrl": "",
            "imgNum": 1,
            "mobileImgUrl": "",
            "newImgUrl": "",
            "mobileFileSize": 0,
            "newImgWidth": 0,
            "fileSize": 0,
            "background": "",
            "frameNum": 0,
            "image_id": 0,
            "mobileImgWidth": 0,
            "mobileImgHeight": 0,
            "effect": 0,
            "newImgHeight": 0,
            "imgWidth": 0,
            "frame": [],
            "imgHeight": 0,
            "desc": "",
            "style": 0,
            "fileName": ""
        }
    });

    //  comic Collection
    var ComicList = Backbone.Collection.extend({
        model: ComicModel,
        initialize: function () {

        },
        parse: function (data) {
            return data.page;
        }
    });

    //  comic Router
    var ComicRouter = Backbone.Router.extend({
        initialize: function () {
            console.log('router');
            this.scroll = {};
        },
        routes: {
            "": "index",
            "help": "help",
            "chapterList": "chapterList"
        },
        index: function () {
            this.pageShow('#comicMainView', 1);
        },
        pageShow: function(selector, isIndex){
            var scroll = this.scroll;
            $('.page-view').removeClass('page-show').hide();
            $('[dlg-type="dlg"]').remove();
            $(selector).show()
            setTimeout(function(){
                $(selector).addClass('page-show');
            },0);
            if(isIndex) {
                $('.tucao-bar,.comic-chapterRel').show();
                window.scrollTo(scroll.x, scroll.y);
            } else {
                $('.tucao-bar,.comic-chapterRel').hide();
                window.scrollTo(0, 0);
            }
        },
        chapterList: function () {
            if( !this.chapterListView ) {
                this.chapterListView = new ChapterListView();
            }
            this.scroll = {x: window.scrollX, y: window.scrollY};
            this.pageShow('#chapterListView');
            window.scrollTo(0,0);
        },
        help: function () {
            console.log('help page');
        }
    });

    //  comic View
    var ComicView = Backbone.View.extend({
        tagName: 'div',
        className: 'comic-page',
        template: _.template($('#comicPageTpl').html()),
        events: {

        },
        initialize: function () {
            //this.listenTo(this.model, 'change', this.update);
        },
        render: function () {
            var model = this.model;
            this.$el
                .attr('data-index', model.get('index'))
                .attr('data-id', model.get('image_id'))
                .css('height', model.get('height'))
                .html(this.template(model.toJSON()));
            return this;
        },
        update: function () {

        }
    });

    // comic list
    var ComicListView = Backbone.View.extend({
        el: '#comicBoxInner',
        events: {},
        bindZoomAction: function () {
            var that = this;
            that.zoomScroll = new IZoom('#comicBox', {
                zoom: true,
                scrollX: true,
                scrollY: true,
                mouseWheel: true,
                zoomMin: 1,
                zoomMax: 2,
                startZoom: 1,
                resizeScrollbars: true,
                mouseWheelSpeed: 10,
                scrollbars: false,
                snap: false,
                snapThreshold: 0.1
            });
            console.log( 'that.zoomScroll.scale',that.zoomScroll.scale )
        },
        _init: function () {
            this.zoomEvent = {
                zoomMin: 1,
                zoomMax: 2
            };
            //this.bindZoomAction();
            this.el.offset = this.$el.offset();

            //trigger chapterNavigater view render;
            this.chapterNavView.render();
        },
        initialize: function (options) {
            console.log('view initialize');
            var that = this;
            this.renderDanMuCall =  utils.noop

            $.extend(this, options);
            this.chapterNavView = new chapterNavigateView();

            this.collection = new ComicList();
            var comicList = COMIC_JSON['page'];
            this.collection.add(comicList);

            this.listenTo(this.collection, 'reset', this.render);
            this.bind('comicComplete', this.comicComplete);
            this.collection.trigger('reset');

            //this.collection.fetch({reset: true});
            //图片加载计数器
            this.comicRenderDone = 0;
            this.comicsLength = 0;
        },
        render: function () {
            this.$el.empty();
            var winW = $(window).width();
            var ratio = 1;
            this.comicsLength = this.collection.length;

            this.collection.each(function (model, i) {
                var ratio = winW / model.get('imgWidth');
                model.set({'index': i + 1, 'height': model.get('imgHeight') * ratio + 'px'});
                this.renderComic(model);
                this.preloadImage(model.get('mobileImgUrl'), model.get('image_id'), this);
            }, this);
            this._init();
        },
        progressListener: function ($comicPage, $comic) {
            //bind danmu播放 事件
            $comicPage.on('danmu', this.renderDanMuCall);
            if (this.comicsLength == this.comicRenderDone)
                this.trigger('comicComplete');
        },
        loadComplete: function ($el, imgSrc, $p) {
            var $comicPage = $el.parents('.comic-page');
            $el.attr('src', imgSrc).removeClass('opacity');
            $comicPage.css('height', 'auto');
            $('.comic-index', $comicPage).remove();
            this.comicRenderDone += 1;
            this.progressListener($comicPage, $el);
        },
        comicComplete: function (callback) {
            //all comic image render complete.
            console.log('rest comic height:auto');
            $('.comic-page').css('height', 'auto');
            var callFn = this.options && this.options.comicCompleteCallback;
            if (callFn) callFn.call(this, arguments);
        },
        preloadImage: function (imgSrc, imgId, context) {
            if (!imgSrc) reutrn;
            var $p = context.$el;
            var item = $p.find('.comic-page[data-id="' + imgId + '"] img');
            item.data('loading', true);
            item.data('loaded', false);
            var img = new Image();
            var onComplete = function () {
                item.data('loading', false);
                item.data('loaded', true);
                if (context.loadComplete) {
                    context.loadComplete(item, imgSrc, $p);
                }
                img.onload = img.onerror = null;
                img = null;
                $parent = null;
            };
            img.onload = onComplete;
            img.onerror = function () {
                item.data('loadError', true);
                onComplete();
            };
            img.src = imgSrc;// + '?a=' + Math.random();
            return img;
        },
        renderComic: function (comic) {
            var comicView = new ComicView({ model: comic });
            this.$el.append(comicView.render().el);
        }
    });

    var BarModel = Backbone.Model.extend({
        "site_www": "",
        "site_static": "",
        "authoruid": "",
        "author_name": "",
        "comic_name": "",
        "chapter_name": "",
        "chapter_id": "",
        "curPage": "1",
        "comic_id": ""
    });

    var BarNavView = Backbone.View.extend({
        el: '#comic-mainNav',
        template: _.template($('#comicBarNavTpl').html()),
        initialize: function () {
            this.render();
        },
        render: function () {
            this.$el.show().html(this.template(this.model.toJSON()));
        }
    });

    var chapterRelView = Backbone.View.extend({
        el: 'body',
        template: _.template($('#comicChapterRelTpl').html()),
        initialize: function () {
            this.listenTo(this.model, 'change:curPage', this.pageNumUpdate);
            this.render();
            this.$chapterRel = $('.comic-chapterRel');
            this.$curPage = this.$el.find('.comic-curPage');
        },
        pageNumUpdate: function () {
            this.$curPage.html(this.model.get('curPage'));
        },
        render: function () {
            this.$el.show().append(this.template(this.model.toJSON()));
        }
    });

    /**
     * 弹幕
     */
    // DanMu Model
    var DanMuModel = ComicModel.extend({
        defaults: {
            "id": "",
            "image_id": "",
            "chapter_id": "",
            "comic_id": "",
            "author_sina_user_id": "",
            "sina_user_id": "",
            "status": "",
            "txtstr": "",
            "x": "0",
            "y": "0",
            "pagedir": "0",
            "needledir": ""
        },
        url: AJAX_API['tcSend']
    });
    // DanMu Collection
    var DanMuList = Backbone.Collection.extend({
        model: DanMuModel,
        url: AJAX_API['tcFetch'],
        initialize: function () {
        },
        parse: function (lists) {
            var result = [];
            _.each(lists.data, function (list) {
                while (_.isArray(list) && list.length) {
                    result.push(list.shift());
                };
            });
            return result;
        }
    });
    // Danmu View
    var DanMuView = Backbone.View.extend({
        tagName: 'div',
        template: _.template($('#danMuTpl').html()),
        initialize: function () {
            this.render();
        },
        render: function () {
            this.$el.html( this.template(this.model.toJSON() ));
            return this;
        }
    });
    var DanMuListView = Backbone.View.extend({
        el: '#comicBox',
        events: {},
        initialize: function (options) {
            var that = this;
            this.danmuPools = [];
            this.danmuCounter = 0;
            this.imageId = options.imageId;
            this.collection = new DanMuList();
            this.listenTo(this.collection, 'reset', this.render);
            this.listenTo(this.collection, 'add', this.tcAddDanMu);
            //if(this.imageId != '893609') return;
            this.$comicPage = $('.comic-page[data-id="' + this.imageId + '"]', this.$el);
            this.comicPageHeight = this.$comicPage.height();
            this.collection.fetch({reset: true, data: {
                "image_id_list": that.imageId, "row_num": TC_ROW_NUM
            } });

            this._timers = [];
            this.delay = 0;
            this.token = this.getToken();
        },
        getToken: function(){
            return _.uniqueId('token_');
        },
        render: function (data) {
            if( this.$comicPage.data('danmu') == 'play' ) return;
            this.$comicPage.data('danmu', 'play');
            this.collection.each(function (model) {
                //纠正 tucao x为负值的情况
                var imageId = model.get('image_id');
                this.tucaoPosYCorrector(model);
                this.renderDanMu(model, imageId);
            }, this);
        },
        tcAddDanMu: function(model){
            var imageId = model.get('image_id');
            this.tucaoPosYCorrector(model);
            this.renderDanMu(model, imageId, 'new');
        },
        tucaoPosYCorrector: function (model) {
            var modelY = model.get('y');
            var comicPageHeight = this.comicPageHeight;
            if (modelY <= 0 ) model.set('y', _.random(20, 80));
            if (modelY >= comicPageHeight - 50) model.set('y', comicPageHeight - _.random(30, 50));
        },
        renderDanMu: function (model, imageId, isNew) {
            if(isNew) model.set('sina_user_id', MANHUA_META.sina_user_id);
            var danMu = new DanMuView({'model': model});
            var $el = $(danMu.$el.html());
            if(isNew) {
                $el.prependTo( this.$comicPage );
            } else {
                this.$comicPage.append($el);
            }
            this.danmuPools.push($el);
            $el.data('width', $el.width());
            this.calculatePosition($el, isNew);
        },
        clearAllTimes: function(){
            while(this._timers.length > 0){
                var timer = this._timers.shift();
                if(timer) clearTimeout( timer );
            }
        },
        stopDanmuAnimi: function(){
            this.danmuCounter = 0;
            this.delay = 0;
            this.danmuPools = [];
            this.token = this.getToken();
            this.clearAllTimes();
        },
        restartDanMu: function( restart ){
            this.stopDanmuAnimi();
            if( !this.$comicPage ) return;
            if( restart ) {
                this.collection.trigger('reset');
                return;
            }
            var that    = this;
            var _width  = $(window).width();
            var $danmus = this.$comicPage.find('.comic-tucao');
            this.delay = 0;

            $danmus.each( function(index, el){
                var $el = $(el);
                that.calculatePosition($el);
            });
        },
        calculatePosition: function ($el, isNew) {
            var that = this;
            var transform = utils.cssPrefixStyle('transform');
            var _width = $('body').width();
            var $prev  = $el.prev('.comic-tucao');
            var top    = $el.data('top');

            $el.show()
               .attr('style', '')
               .css(transform, 'translate3d(' + _width + 'px,0,0)')
               .data('offset-left', _width)
               .css({'visibility': 'hidden', 'top': top});

            var prevWidth = $prev.length ? $prev.data('width') : 0;
            var speed     = 1.5;
            var dest      = $el.data('width') || $el.width();
            var distance  = _width + dest;
            var elapsed   = distance / speed * 20;
            var token = this.token;

            this.delay   += (prevWidth+10) / speed * 20;
            var _timers = setTimeout(function() {
                that.danmu($el, -dest, elapsed, token);
            }, (isNew ? 0 : this.delay) );
            this._timers.push(_timers);
        },
        danmu: function ($el, left, duration, token) {
            var that  = this;
            if( token != this.token) return;
            $el.css({'visibility': 'visible'});
            $el.animate({'translate3d': left + 'px, 0, 0'}, duration, 'linear', function(){
                return that.resetDanmuTranslate($el, token);
            });
        },
        resetDanmuTranslate: function($el,token) {
            if(token != this.token) return false;
            var that = this;
            that.danmuCounter += 1;
            if( that.danmuCounter == that.collection.length ) {
               //restartDanmu滚动弹幕
                that.danmuCounter = 0;
                that.restartDanMu();
                return false;
            };
        },
        danmuCtl: function () {

        }
    });


    /**
     * 目录
     */
    // chaper Model
    var ChapterModel = ComicModel.extend({
        defaults: {
            "chapter_id": "",
            "chapter_name": "",
            "image_num": ""
        },
        initialize: function () {

        }
    });
    var ChapterList = Backbone.Collection.extend({
        model: ChapterModel
    });
    var ChapterListView = Backbone.View.extend({
        el: '#chapterListView',
        initialize: function () {
            this.$wrap = $('.table-view', this.$el);
            this.collection = new ChapterList();
            this.listenTo(this.collection, 'reset', this.render);
            var catalog = json_catalog && json_catalog['chapter_list'];
            this.collection.add(_.toArray(catalog));
            this.collection.trigger('reset');
        },
        render: function () {
            $('.comic-loding', this.$el).remove();
            this.collection.each(function (model) {
                this.renderDir(model);
            }, this);
        },
        renderDir: function (model) {
            var view = new chapterModelView({model: model});
            this.$wrap.append(view.render().el);
        }
    });
    var chapterModelView = Backbone.View.extend({
        tagName: 'li',
        className: 'table-view-cell',
        template: _.template($('#chapterModelTpl').html()),
        initialize: function () {
            if( this.model.get('chapter_id') == CURRENT_CHAPTER) {
                console.log('true');
                this.model.set('is_current', '1');
                this.$el.addClass('current');
            }
        },
        render: function () {
            this.$el.html(this.template(this.model.toJSON()));
            return this;
        }
    });

    var ChapterModel = ComicModel.extend( {
        defaults: function(){
            return {
                "first_chapter_info": json_catalog["first_chapter_info"],
                "end_chapter_info"  : json_catalog["end_chapter_info"],
                "prev_chapter_info" : json_catalog["prev_chapter_info"],
                "next_chapter_info" : json_catalog["next_chapter_info"]
            };
        },
        initialize: function(){}
    } );
    //上一章节/下一章节
    var chapterNavigateView = Backbone.View.extend({
        el: '#comicBoxInner',
        template: _.template( $('#chapterNavigateBtnTpl').html() ),
        initialize: function( options ){
            this.model = new ChapterModel();
        },
        render: function(){
            var $el = $('<div></div>').html( this.template( this.model.toJSON()) );
            $el.find('[data-nav="prev"]').prependTo( this.$el );
            $el.find('[data-nav="next"]').appendTo( this.$el );
        }
    });


    // chaper View
    var app = app || {};
    $.extend(app, {
        init: function () {
            console.log('play start.');
            this.router = new ComicRouter();
            this.appView = new app.view();
            Backbone.history.start();
        }
    });

    var tucaoBarView = Backbone.View.extend({
        el: 'body',
        events: {
            'tap .tc-show': 'tcShowHandler',
            'tap .tc-hide': 'tcBarHiddenHandler',
            'tap .tc-publ': 'tcPublHandler',
            'tap .comic-page': 'tcCheckPositionHandler'
            //'focus textarea': 'fixFocusViewport',
            //'blur textarea': 'resotreFocusViewport'
        },
        template: _.template($('#tuCaoBarTpl').html()),
        initialize: function ( options ) {
            this.appView = options.appView;
            this.danMuShowState = TC_SHOW || 0;
            this.render();
            this._init();
        },
        _init: function () {
            var that = this;
            this.$showBtn  = $('.tc-show', this.$el);
            this.$publBtns = $('.tc-publ', this.$el);
            this.$tools    = $('.tc-tools', this.$el);

            this.tcShow();
            this.$viewPort = this.$viewPort || $('meta[name="viewport"]');
            this.originalViewport = 'width=device-width, initial-scale=1, maximum-scale=2, user-scalable=yes';
            //this.$viewPort.attr('content', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no');
            setTimeout(function(){
                that.resotreFocusViewport();
            }, 2000);
        },
        resotreFocusViewport: function(){
            this.$viewPort.attr('content', this.originalViewport);
        },
        fixFocusViewport: function(){
            this.$viewPort.attr('content', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no');
        },
        tcCheckPositionHandler: function(e, data){
            var that = this;
            if( !__tucaoModal ) return;
            //reset tocao modal state
            that.$tcguide.css('visibility','hidden');
            setTimeout(function(){
                __tucaoModal = false;
                __disableScroll = false;
                that.$tcguide.hide();
            }, 600);

            var $el = $(e.currentTarget);
            var imageId = $el.data('id');
            var meta = MANHUA.meta;
            var position = this.getTcPosition( $el.offset() );

            var model = new DanMuModel({
                'id': null,
                'image_id': imageId,
                'chapter_id': meta['chapter_id'],
                'comic_id': meta['comic_id'],
                'author_sina_user_id': meta['authoruid'],
                'sina_user_id': meta['sina_user_id'],
                'txtstr': that.txtstr,
                'x': position.x,
                'y': position.y
            });
            this.danMuListView = this.appView.getDanMuListView( imageId );
            this.tcSubmitAction( model );
        },
        getTcPosition: function(offset){
            var pointer = utils.getPointer();
            var x = pointer.pageX - offset.left ||  0,
                y = pointer.pageY - offset.top ||  0;
            return {
                'x': x,
                'y': y
            }
        },
        tcSubmitAction: function( model){
            utils.tips('正在吐槽中...', 1);
            var that = this;
            model._save(null, {
                type: 'POST',
                success: function(response){
                    var message = response.message;
                    if(response.code == 1) {
                        message = '吐槽成功';
                        model.set('id', response.data['tucao_id'])
                        that.tcUpdateComicView( model );
                    }
                    utils.tips(message, 0, 1500);
                },
                error: function(){
                    utils.tips('出错了，请稍后再试。',0, 1500);
                }
            });
        },
        tcUpdateComicView: function( model ){
            //this.appView.
            this.danMuListView.collection.add( model );
        },
        tcShowHandler: function (e) {
            var $curComicPage = this.appView.$curComicPage;
            this.tcBarControl('addClass');
            this.danMuShowState = 1;
            this.setTcShowState();
            if(!$curComicPage) {
                $(window).trigger('scroll');
            } else {
                $curComicPage.trigger('danmu');
            }
        },
        setTcShowState: function(){
            utils.storage(TC_SHOW_NAME, this.danMuShowState, TC_SHOW_EXPIRES);
        },
        tcBarHiddenHandler: function (e) {
            this.tcBarControl('removeClass');
            this.danMuShowState = 0;
            this.setTcShowState();
            //all clear
            this.appView.stopDanMu(1);
        },
        tcDlg: function( callback, closeCall ){
            $('<div>').dlg({
                clazz: 'tucao-dlg',
                title: '',
                callback: callback,
                closeCall: closeCall,
                content: $('#tucaoDlgContenTpl').html()
            });
        },
        tcPublHandler: function () {
            var that = this;
            if( Login.require() ) return;
            that.appView.showBarNavAction(1);
            that.tuguideTpl = $('#tuCaoGuideTpl').html();
            if($.os.ios) this.fixFocusViewport();
            this.tcDlg(function () {
                var $dlg = this, content = '';
                __tucaoModal = true;
                content = $.trim( $dlg.find('textarea[name="tucaoTextarea"]').val() );
                if(!content) {
                    utils.tips('吐槽内容不能为空', 0, 1000);
                    setTimeout(function(){
                        __tucaoModal = false;
                    }, 1000);
                    return true;
                }
                that.resotreFocusViewport();
                that.txtstr = content;
                that.tcGuideTips();
            }, function () {
                __tucaoModal = false;
                that.resotreFocusViewport();
            });
        },
        tcGuideTips: function () {
            //吐槽位置蒙版
            __disableScroll = true;
            __tucaoModal = true;

            if (this.$tcguide) {
                this.$tcguide
                    .css('visibility','visible')
                    .show();
                return false;
            }
            this.$tcguide = $(this.tuguideTpl);
            this.$el.append(this.$tcguide);
        },
        tcBarControl: function (action, clazz) {
            if (!action) return false;
            clazz = clazz || 'active';
            this.$showBtn[action](clazz);
            this.$tools[action](clazz);
        },
        tcShow: function(){
            if( this.danMuShowState ) {
                this.$tools.addClass('active');
                this.$showBtn.removeClass('active');
            }
        },
        render: function () {
            this.$el.append( this.template() );
        }
    });

    app.view = Backbone.View.extend({
        el: 'body',
        events: function () {
            $(window).on('scroll', _.bind(this.scoll, this));
            $(window).on('orientationchange', _.bind(this.restartDanMu, this));
            $('body').on('touchmove', _.bind(this.viewPortChange, this));
            return {
                "tap .content": "scoll",
                "tap #comicBox": "actionControlHandler",
                //'doubleTap #comicBox': 'scaleViewHandler',
                'tap .content': 'fixBarNav',
                'tap .comic-page': 'tcSubmitAction'
            }
        },
        initialize: function () {
            var that = this;
            this.comicListView = new ComicListView({
                comicCompleteCallback: function () {},
                renderDanMuCall: function (e) {
                    // state = 1 为显示弹幕
                    if( !that.tucaoV ) return;
                    if( !that.tucaoV.danMuShowState ) return;
                    var updateDanmuIdsPool = null;
                    updateDanmuIdsPool = _.union( that.danmuIdsPool, that.originDanmuIdsPool );
                    updateDanmuIdsPool = _.difference( updateDanmuIdsPool, that.originDanmuIdsPool );
                    that.renderDanMuList( updateDanmuIdsPool );
                }
            });
            this.barModel = new BarModel();
            this.metaRestore();
            this.barModel.set(MANHUA.meta);
            this.render();
            this.timer = null;
            //touch事件获取 touches event;
            this.touchEvent = utils.touchEvent;

            this.$comicBoxInner = $('#comicBoxInner');
            this.scaleMax = 2;
            this.scaleMin = 1;
            this.scale = 1;
            this.$comicBoxInner.css(utils.cssPrefixStyle('transform-origin'), '0 0');

            var $win = $(window);
            //viewport 缩放  $()
            this.$window = $win;
            this.deviceWidth = $('body').width();
            this.viewScaleRatio = this.deviceWidth / this.$window.width();
            this.getViewOffset();

            this.initDanMu();
        },
        initDanMu: function(){
            //弹幕
            this.danMuListViews = {};
            this.originDanmuIdsPool = [];
            this.getCurrentPage();
            if( !this.tucaoV.danMuShowState ) return ;
            this.danmuIdsPool = _.union( this.danmuIdsPool );
            this.renderDanMuList( this.danmuIdsPool );
        },
        getViewOffset: function(){
            var $win = this.$window;
            return this.viewOffset = {
                top: 0,
                left: 0,
                width: $win.width(),
                height: $win.height()
            };
        },
        metaRestore: function () {
            //MANHUA.meta.pageNum = COMIC_JSON['header']['pageNum'];
            var pageNum = COMIC_JSON['header'] && COMIC_JSON['header']['pageNum'];
            $.extend(MANHUA.meta, { "curPage": 1 , "pageNum": pageNum });
        },
        render: function () {
            this.renderBarNav();
            this.removeLoading();
        },
        removeLoading: function () {
            setTimeout(function () {
                $('.comic-loadBox').remove();
            }, 0);
        },
        getCurrentPage: function () {
            var index = 1;
            var that = this;
            var winH = $(window).height();
            var pageHeight = document.body.scrollHeight;
            var __scrollY  = window.scrollY;
            var inViewport = winH + __scrollY;
            var $comicPage = this.$comicPages || $('#comicBox .comic-page');
            this.danmuIdsPool = [];
            this.currentPages = [];
            this.danmuMvPool = [];
            $comicPage.each(function (i, comic) {
                var $comic = $(comic);
                var offset = $comic.data('offset') || $comic.offset();
                if (!$comic.data('offset')) $comic.data('offset', offset);
                var top = offset.top;
                var __scrollTop = __scrollY + winH * 1/2;
                if (__scrollTop <= top + offset.height) {
                    index = $comic.data('index');
                    var comicId;
                    var $prev = $comic.prev('.comic-page');
                    var $next = $comic.next('.comic-page');
                    var prevOffset = $prev.length > 0 ? $prev.offset() : 0;
                    var nextOffset = $next.length > 0 ? $next.offset() : 0;

                    that.danmuIdsPool.push($comic.data('id'));
                    that.currentPages.push($comic);

                    if( __scrollY == 0 ) {
                        var $firstPage = $comicPage.eq(0);
                        comicId = $comicPage.eq(0).data('id');
                        that.danmuIdsPool.push(comicId);
                        that.currentPages.push($firstPage);
                    }

                    if(prevOffset && (prevOffset.top + prevOffset.height >= __scrollY + 10) ) {
                        comicId = $prev.data('id');
                        that.danmuIdsPool.push(comicId);
                        that.currentPages.push($prev);
                    }
                    if( nextOffset && ( nextOffset.top <= inViewport - 10 ) ) {
                        comicId = $next.data('id');
                        that.danmuIdsPool.push(comicId);
                        that.currentPages.push($next);
                    }
                    //$.each(that.currentPages, function(index, el){
                    $.each($comicPage, function(index, el){
                        var $el = $(el);
                        if(_.indexOf( that.danmuIdsPool, $el.data('id') ) != -1){
                            $el.trigger('danmu');
                            return;
                        }
                        $el.data('danmu', 'paused');
                        that.danmuMvPool.push( $el.data('id') );
                        that.stopDanMu(null, $el);
                    });
                    that.$curComicPage = $comic;
                    return false;
                }
            });
            if( inViewport >= pageHeight - 20) index = MANHUA.meta.pageNum;
            if( __scrollY <= 0 ) index =1;
            return index;
        },
        scoll: function (e) {
            var that = this;
            clearTimeout(that.timer);
            that.timer = setTimeout(function () {
                that.barModel.set({ "curPage": that.getCurrentPage() });
            }, 60);
        },
        restartDanMu: function(){
            this.stopDanMu(1);
            $(window).trigger('scroll');
            console.log('orientationchange.');
        },
        getPointerPos: function () {
            var viewOffset = this.getViewOffset();
            var getPointer = utils.getPointer();
            var viewHeight = viewOffset.height ;
            var clientY = getPointer.clientY;
            if (clientY >= 0 && clientY <= viewHeight * 1 / 3) return 'top';
            if (clientY >= viewHeight * 1 / 3 && clientY <= viewHeight * 2 / 3) return 'center';
            return 'bottom';
        },
        tcSubmitAction: function () {
            var pointer = utils.getPointer();
            this.actionControl = true;
            //console.log('提交吐槽', pointer);
        },
        cancelActionCtl: function () {
            if (this.actionCtlTimer) clearTimeout(this.actionCtlTimer);
        },
        getViewScaleRatio: function(){
            return Math.max(1, this.deviceWidth / this.$window.width() );
        },
        viewPortChange: function(e){
            if( e.touches.length < 2 ) return;
            this.viewScaleRatio = this.getViewScaleRatio();
            if( this.viewScaleRatio > 1) {
                //console.log('hide');
                //this.barNavVisible('hide');
            }else {
                this.barNavVisible('show');
                console.log('show');
            }
        },
        fixBarNav: function(e){
           var that = this;
           if( this.fixTimer ) clearTimeout( this.fixTimer );
           this.fixTimer =  setTimeout(function(){
               if(that.getViewScaleRatio() > 1) return;
               //that.cancelActionCtl();
               that.barNavVisible('show');
            }, 100);
        },
        scaleViewHandler: function (e) {
            var that = this;
            return false;
            //吐槽模式
            if( __tucaoModal ) return;
            //doubleTap sacel
            var transformStyle = [];
            var pointer = utils.getPointer();
            var pageX = pointer.pageX;
            var pageY = pointer.pageY;
            var newScrollX = 0;
            var newScrollY = 0;

            this.cancelActionCtl();
            this.scale = this.scale == 1 ? this.scaleMax : this.scaleMin;

            if (this.scale > 1) {
                newScrollX = window.scrollX + pageX * this.scale - pageX;
                newScrollY = window.scrollY + pageY * this.scale - pageY;
                this.barNavVisible('hide');
            } else {
                newScrollX = window.scrollX - pageX / 2;
                newScrollY = window.scrollY - pageY / 2;

                newScrollX = newScrollX < 0 ? 0 : newScrollX;
                newScrollY = newScrollY < 0 ? 0 : newScrollY;
                this.barNavVisible('show');
            }
            this.$comicBoxInner.css(utils.cssPrefixStyle('transform'), 'translate3d(0,0,0) scale(' + this.scale + ')');
            //this.$comicBoxInner.css( utils.cssPrefixStyle('transition'), 'all 0.3s ease' );
            console.log(newScrollX, newScrollY);
            window.scrollTo(newScrollX, newScrollY);
        },
        actionControlHandler: function (e) {
            var that = this;
            var viewScaleRatio = that.getViewScaleRatio();
            this.cancelActionCtl();
            if( __tucaoModal ||  viewScaleRatio > 1) return;
            this.actionCtlTimer = setTimeout(function () {
                var pos = that.getPointerPos();
                if (pos == 'top') that.prevScreenAction();
                if (pos == 'center') that.showBarNavAction();
                if (pos == 'bottom') that.nextScreenAction();
            }, 200);
        },
        nextScreenAction: function () {
            var from = window.scrollY;
            var to = from + this.getViewOffset().height;
            if (to <= document.body.scrollHeight) this.windowScrollToWithAnim(from, to, 10);
        },
        prevScreenAction: function () {
            var from = window.scrollY;
            var to = from - this.getViewOffset().height;
            if( to < 0 ) to = 0;
            this.windowScrollToWithAnim(from, to, 10);
        },
        windowScrollToWithAnim: function (from, to, speed) {
            var that = this;
            var start = +new Date;
            var velocity = 0;
            var timeElap = 0;

            if (this.scrollTimer) clearInterval(this.scrollTimer);
            this.scrollTimer = setInterval(function () {
                timeElap = +new Date - start;
                console.log( timeElap > speed );
                if (timeElap > speed) {
                    window.scrollTo(0, to);
                    clearInterval(that.scrollTimer);
                    return false;
                }
                velocity = (( (to - from) * (Math.floor((timeElap / speed) * 100) / 100) ) + from);
                console.log('velocity', velocity)
                window.scrollTo(0, velocity);
            }, 4);
        },
        showBarNavAction: function ( close ) {
            if (this.scale > 1) return;
            var $barV = this.barV && this.barV.$el;
            if (!$barV) return;
            if (close || $barV.hasClass('active')) {
                $barV.removeClass('active');
            } else {
                $barV.addClass('active');
            }
        },
        barNavVisible: function (visible) {
            var $bar = $('.bar, .comic-chapterRel');
            if( !$bar.length ) return;
            if (visible == 'hide') {
                $('#comicBox').css('position', 'static');
                $bar.css('visibility', 'hidden');
            } else {
                $bar.css('position', 'fixed');
                $('#comicBox').css({'position': 'relative', 'left': '0'});
                $bar.css('visibility', 'visible');
            }
        },
        renderBarNav: function () {
            this.barV = new BarNavView({model: this.barModel });
            this.chapterV = new chapterRelView({model: this.barModel });
            this.tucaoV   = new tucaoBarView({appView: this});
        },
        renderChapterList: function () {
            //this.chapterListView = new ChapterListView();
        },
        stopDanMu: function(isAll, $target){
            var $comicPage = $('.comic-page', this.$el);
            
            $target = $target || this.$el;
            if( !isAll ) {
                $comicPage = $target;
            } else {
                this.originDanmuIdsPool = [];
            }
            $comicPage.data('danmu', 'paused');
            $('.comic-tucao', $target).remove();
        },
        getDanMuListView: function(imageId){
            if(!imageId) return ;
            return this.danMuListViews[imageId] || new DanMuListView({imageId: imageId})
        },
        renderDanMuList: function (imageIds) {
            //.slice复制副本，非引用
            this.originDanmuIdsPool = this.danmuIdsPool.slice();
            if( !imageIds.length ) return;
            _.each(imageIds, function(imageId, index){
                if( !this.danMuListViews[imageId]) {
                    this.danMuListViews[imageId] = new DanMuListView({imageId: imageId});
                } else {
                    this.danMuListViews[imageId].restartDanMu('restart');
                }
            }, this);
        }
    });
    return app;
});