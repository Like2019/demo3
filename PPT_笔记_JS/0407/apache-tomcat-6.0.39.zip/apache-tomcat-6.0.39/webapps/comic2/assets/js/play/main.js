requirejs.config({
    baseUrl: (MANHUA.local ? './':MANHUA['static']+'/comic/') + 'assets/js',
    urlArgs: 'v='+ (MANHUA.version||1),
    paths: {
        jquery: 'libs/zepto',
        backbone: 'libs/backbone',
        fastclick: 'libs/fastclick',
        underscore: 'libs/underscore',
        //touch: 'http://touch.code.baidu.com/touch-0.2.14.min',
//        hammer: 'http://hammerjs.github.io/dist/hammer.min',
        zoom: 'libs/iscroll-zoom',
        utils: 'modules/utils',
        dlg: 'modules/zepto.dlg',
        login: 'modules/login',
        comicPlay: 'modules/play'
    },
    shim: {
        underscore: {
            exports: '_'
        },
        utils: {
            deps: ['jquery'],
            exports: 'utils'
        },
        backbone: {
            deps: ['jquery', 'underscore'],
            exports: 'Backbone'
        },
        jquery: {
            exports: '$'
        },
        dlg: {
            deps: ['jquery'],
            exports: '$.fn.dlg'
        }
    }
});


require(['fastclick', 'comicPlay'], function(FastClick, app){
    //$(function(){ FastClick.attach(document.body); });
    $(function(){ app.init(); });
    window.__tucaoModal = false;
    window.__disableScroll = false;

//    utils.tcDlg();
//    utils.tips('我去了, 还没有完成呀。');

    //dlg 打开时, 禁用滚动条
    $(document).bind('touchmove', function(e){
        if(window.__disableScroll) e.preventDefault();
        if(window.__tucaoModal) e.preventDefault();
    });
});
