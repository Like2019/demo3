var gulp = require('gulp');
var jshint = require('gulp-jshint');
var concat = require('gulp-concat');
var uglify = require('gulp-uglify');
var rename = require('gulp-rename');

// 语法检查
gulp.task('jshint', function () {
    return gulp.src('src/*.js')
        .pipe(jshint())
        .pipe(jshint.reporter('default'));
});

// 合并文件之后压缩代码
gulp.task('minify', function (){
    return gulp.src([
        'js/zepto/zepto.js',
        'js/zepto/selector.js',
        'js/zepto/event.js',
        'js/zepto/ajax.js',
        'js/zepto/form.js',
        'js/zepto/data.js',
        'js/zepto/ie.js',
        'js/zepto/detect.js',
        'js/zepto/assets.js',
        'js/zepto/touch.js',
        'js/zepto/fx.js',
//        'js/zepto/fx_methods.js',
        'js/zepto/src/callbacks.js',
        'js/zepto/src/deferred.js',
        'js/zepto/src/stack.js',
        'js/zepto/src/ios3.js'
        ]).pipe(concat('zepto.js'))
        .pipe(gulp.dest('js/libs'))
//        .pipe(uglify())
        .pipe(rename('zepto.js'))
        .pipe(gulp.dest('js/libs'));
});



// 注册缺省任务
gulp.task('default', ['jshint', 'minify']);