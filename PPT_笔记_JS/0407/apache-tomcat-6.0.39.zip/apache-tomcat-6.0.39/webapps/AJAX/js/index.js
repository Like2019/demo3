﻿		//document.wirte方法，可以像浏览器输出文本内容
		//当需要输出标签的时候，需要使用转义字符&lt; 代表<   &gt; 代表>
		document.write("做人没有理想，那跟咸鱼有什么分别————周星驰&lt;script&gt; <br>");
		document.write("人生就像一盒巧克力，你永远不会知道下一个是什么味道————阿甘</br>");
		
		//variable 代表可变的量，这里用简称作为语言的关键字
		var age = 18;
		var weight = 108;
		var name = "尹涛";
		//尹涛的年龄是18，体重是108
		
		//多个变量跟字符串连接的时候，使用+号
		document.write(name+"的年龄是"+age+",体重是"+weight+"<br>");
		
		var num1 = 20.7;
		var num2 = 10;
		
		//alert(num2%3); //结果是1
		//alert(3%num2); //结果是3，如果左边的数字更小，求余数的结果就是它本身
		
		//
		var bn = true;
		alert(num2 + bn); //结果是 11
		//在这里，浏览器对变量自动做了类型转换,把布尔类型转换成了一个number类型，再做加法
		
		document.write(num1+num2+"<br>");
		//typeof用来获取变量的数据类型
		var num3 ="99.9";
		document.write(typeof num3);
		//给变量起名字,一定要遵守见名知意的原则
		//alert(num1==num2);//布尔类型的结果，它只有两种取值，true和false
		
		
		var res = num1==num2;
		//alert(typeof res);
		
		//当一个变量不存在的时候，是无法访问的，浏览器会报错
		//alert(abc);
		/*
			sdfsdfsdf
			sdfsdfsdf
			多行注释
		*/
		var a=1,b=2,c=3,d=4;//可以一次定义多个变量
		
		//alert(a+b+c+d);
		
		var str1 = "";
		var str2 = null;
		//空字符串和null空值  是两个概念，不要搞混
		//alert(str1 == str2);
		
		//alert(typeof str2);//返回object
		
		
		//数据类型的问题
		//
		