﻿function test(){
	//从第一个输入框当中获取它的内容
	var num1Val = document.getElementById("num1").value;
	//从第二个输入框当中获取它的内容
	var num2Val = document.getElementById("num2").value;
	
	//alert(typeof parseInt(num1Val));
	//将获取到的字符串手动转换成number类型，再做加法运算，将得到的结果放入第三个输入框
	//parseInt() 可以将字符串转换成整数， parseFloat()可以将字符串转换成浮点数
	//Math.round() 可以对数字进行四舍五入
	document.getElementById("res").value = parseFloat(num1Val) + parseFloat(num2Val);
	
}

function test2(){
	var num1Val = document.getElementById("num1").value;
	var num2Val = document.getElementById("num2").value;
	document.getElementById("res").value = parseFloat(num1Val) - parseFloat(num2Val);
	
}

function test3(){
	var num1Val = document.getElementById("num1").value;
	var num2Val = document.getElementById("num2").value;
	document.getElementById("res").value = parseFloat(num1Val) * parseFloat(num2Val);
	
}

function test4(){
	var num1Val = document.getElementById("num1").value;
	var num2Val = document.getElementById("num2").value;
	document.getElementById("res").value = parseFloat(num1Val) / parseFloat(num2Val);
	
}