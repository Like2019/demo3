
cbk("{city:'SH',mintemp:-1,maxtemp:3,wind:3, pm2_5: 50}");